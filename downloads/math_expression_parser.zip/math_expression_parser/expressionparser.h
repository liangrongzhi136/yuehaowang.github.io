#ifndef EXPRESSIONPARSER_H
#define EXPRESSIONPARSER_H


#include <iostream>


using namespace std;

typedef pair<char, char> OPair;

class ExpressionParser
{
public:

	float getValue(const string& exp) const;

protected:

	string removeSpaces(const string& str) const;
	string trimmed(const string& str) const;
	void handleBrackets(string& exp) const;
	void handleOperator(string& exp, OPair operators) const;
	string floatToString(float f) const;
	float stringToFloat(const string& s) const;
	float basicCalc(const string& s1, const char o, const string& s2) const;
	bool isOperator(const char c) const;
	bool isSpace(const char c) const;

};


#endif // EXPRESSIONPARSER_H
