#include <stdlib.h>
#include <sstream>
#include "expressionparser.h"


#define WRONG_EXP 1

float ExpressionParser::getValue(const string& exp) const
{
	string __exp = trimmed(exp);

	handleBrackets(__exp);
	handleOperator(__exp, OPair ('*', '/'));
	handleOperator(__exp, OPair ('+', '-'));

	return stringToFloat(__exp);
}

string ExpressionParser::removeSpaces(const string& str) const
{
	string res;

	for (int i = 0; i < (int)str.size(); i++) {
		char c = str[i];

		if (!isSpace(c)) {
			res += c;
		}
	}

	return res;
}

string ExpressionParser::trimmed(const string& str) const
{
	int l = str.size();
	int i = 0, j = l - 1;

	{
		char c = str[i];

		while (isSpace(c)) {
			c = str[++i];
		}
	}

	{
		char c = str[j];

		while (isSpace(c)) {
			c = str[--j];
		}
	}

	return str.substr(i, j - i + 1);
}

void ExpressionParser::handleBrackets(string& exp) const
{
	int open = 0;
	int lbIndex = -1;
	int l = exp.size();

	for (int i = 0; i < l; i++) {
		char c = exp[i];

		if (c == '(') {
			if (open == 0) {
				lbIndex = i;
			}

			open++;
		} else if (c == ')') {
			open--;

			if (open == 0) {
				int start = lbIndex + 1;

				if (i <= start) {
					break;
				}

				string bracketContent = exp.substr(start, i - start);
				string after = floatToString(getValue(bracketContent));

				exp = exp.substr(0, lbIndex) + after + (((i + 1) < l) ? exp.substr(i + 1) : "");
				l = exp.size();
				i = lbIndex + after.size() - 1;
			} else if (open < 0) {
				break;
			}
		}
	}

	if (open != 0) {
		throw WRONG_EXP;
	}
}

void ExpressionParser::handleOperator(string& exp, OPair operators) const
{
	int l = exp.size();
	int preO = -1;

	for (int i  = 0; i < l; i++) {
		char c = exp[i];

		if (isOperator(c)) {
			int ppi = preO + 1;

			string strNum1, strNum2;

			int tempI = i;

			{
				int j = i + 1;

				while (j < l) {
					char __c = exp[j];

					if (!isSpace(__c)) {
						if (isOperator(__c)) {
							if (__c == c) {
								throw WRONG_EXP;

								return;
							}

							i = j;
						} else {
							i = j - 1;
						}

						break;
					}

					j++;
				}
			}

			if (c == operators.first || c == operators.second) {
				int k = i + 1;

				while (!isOperator(exp[k]) && k < l) {
					k++;
				}

				strNum1 = trimmed(exp.substr(ppi, tempI - ppi));
				strNum2 = trimmed(exp.substr(tempI + 1, k - tempI - 1));

				string strVal = floatToString(basicCalc(strNum1, c, strNum2));

				exp = exp.substr(0, ppi) + strVal + exp.substr(k);

				l = exp.size();
				i = ppi + strVal.size() - 1;
			} else {
				preO = tempI;
			}
		}
	}
}

string ExpressionParser::floatToString(float f) const
{
	ostringstream oss;

	if (!(oss << f)) {
		throw WRONG_EXP;

		return  "";
	}

	return oss.str();
}

float ExpressionParser::stringToFloat(const string& s) const
{
	string __s = removeSpaces(s);

	istringstream iss(__s);

	float f;

	iss >> std::ws >> f >> std::ws;

	if(__s.size() <= 0 || (__s.size() == 1 && isOperator(__s[0])) || !iss.eof()) {
		throw WRONG_EXP;
	}

	return f;
}

float ExpressionParser::basicCalc(const string& s1, const char o, const string& s2) const
{
	float n1 = stringToFloat(s1), n2 = stringToFloat(s2);

	if (o == '+') {
		return n1 + n2;
	} else if (o == '-') {
		return n1 - n2;
	} else if (o == '*') {
		return n1 * n2;
	} else if (o == '/') {
		return n1 / n2;
	} else {
		throw WRONG_EXP;
	}

	return 0.0;
}

bool ExpressionParser::isOperator(const char c) const
{
	return c == '+' || c == '-' || c == '*' || c == '/';
}

bool ExpressionParser::isSpace(const char c) const
{
	return c == ' ' || c == '\n' || c == '\r' || c == '\t';
}
