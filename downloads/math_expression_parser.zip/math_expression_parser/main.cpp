#include <iostream>
#include "expressionparser.h"


using namespace std;

int main()
{
	string exp;

	cout << "Please input a math expression: ";
	getline(cin, exp);

	ExpressionParser expParser;

	try {
		float val = expParser.getValue(exp);

		cout << val << endl;
	} catch (int errCode) {
		if (errCode == 1) {
			cout << "Wrong expression." << endl;
		} else {
			cout << "Uncaught exception." << endl;
		}
	}

	return 0;
}
